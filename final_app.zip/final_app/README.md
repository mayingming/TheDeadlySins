## TECH
- map programmed based on 'mapbox'
  
## prep
Use editor viscose to open this director and install a 'live server' extension (can be obtained at left side tool bar)，click on 'open with live server' on index.html

## please open when connecting to inner wifi of Melbourne university
## or using Cisco VPN of Melbourne Uni since the added layer needs back end data that is ## originated from Melbourne Uni domain
