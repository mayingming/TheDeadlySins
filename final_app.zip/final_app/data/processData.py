# 处理得到所有需要的数据
import json

with open('data/cityCrime.json', 'r') as f:
    oldCityData = json.load(f)
    with open('data/crimeSource.json', 'r') as cf:
        source = json.load(cf)
        cities = source['features']
        for index, city in enumerate(cities):
            cityInfo = city['properties']
            burglary = cityInfo['b30_burglary_break__and__enter']
            theft = cityInfo['b40_theft']
            robery = cityInfo['a50_robbery']
            drug = cityInfo['c10_drug_dealing__and__trafficking']
            total = cityInfo['grand_total_offence_count']

            oldCityData['features'][index]['properties']['burglary'] = burglary
            oldCityData['features'][index]['properties']['theft'] = theft
            oldCityData['features'][index]['properties']['robery'] = robery
            oldCityData['features'][index]['properties']['drug'] = drug
            oldCityData['features'][index]['properties']['drug'] = drug
            oldCityData['features'][index]['properties']['total'] = total

        with open('data/finnalCrimeData.json', 'w') as f:
            json.dump(oldCityData, f)
