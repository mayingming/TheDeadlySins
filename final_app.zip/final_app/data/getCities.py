# 遍历获取每个城市的polygon
import requests
import json
url = "http://polygons.openstreetmap.fr/get_geojson.py"

with open('data/cityCrime.json', 'r') as f:
    cityData = json.load(f)
    cities = cityData['features']

    for index, city in enumerate(cities):
        cityId = city['properties']['osm']
        payload = {'id': cityId}
        r = requests.get(url, params=payload)
        if r.status_code == 200:
            city['polygon'] = r.json()
            city['cityName'] = city['properties']['lga']
            print(city['cityName'] + ': done')
            with open('data/cities/' + city['cityName'] + '.json', 'w') as f:
                json.dump(city['polygon'], f)
