## TECH
- map programmed based on 'mapbox'
  
## prep
Use editor viscose to open this director and install a 'live server' extension (can be obtained at left side tool bar)，click on 'open with live server' on index.html
