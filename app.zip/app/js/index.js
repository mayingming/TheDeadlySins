$(document).ready(function() {
	// var ip = 'http://118.25.22.201:3001/mock/43'
	var ip = 'http://103.6.254.126:5984'
	var allUrl = ip + '/final_result/_design/result/_view/all?group_level=2'
	var locationUrl = ip + '/final_result/_design/result/_view/location?group_level=2'
	// 初始化fullpage
	var myFullpage = $('#fullpage').fullpage({
		menu: '#nav-mobile',
		navigation: true,
		slidesNavigation: true,
		anchors: ['home', 'page1', 'page2', 'page3']
	})

	var chartData = {
		crime: [],
		income: [],
		drug: []
	}

	// 顶部导航
	$('.sidenav').sidenav()

	var cities = []
	var colorList = [
		'#f83a21',
		'#f84f1d',
		'#f96f1b',
		'#fcd15c',
		'#daf2ff',
		'#fde8ab',
		'#f8f2dc',
		'#4cb4e7',
		'#71bdfe',
		'#e8f5f6'
	]

	var propNum = {
		crime: {},
		income: {},
		drug: {},
		greedy: {}
	}
	var cityPos = {}
	var twitterInfo = {
		all: {},
		local: {},
		percent: {}
	}
	var numList = {
		crime: [],
		income: [],
		drug: [],
		greedy: []
	}
	var max = {
		crime: null,
		income: null,
		drug: null,
		greedy: null
	}
	var min = {
		crime: null,
		income: null,
		drug: null,
		greedy: null
	}
	var dif = {
		crime: null,
		income: null,
		drug: null,
		greedy: null
	}
	var map = {
		crime: null,
		income: null,
		drug: null
	}

	function initIndexData(type, page) {
		numList[page] = []
		$.each(cities, function(index, city) {
			var cityName = city.properties.lga
			var num = city.properties[type]

			cityPos[cityName] = city
			propNum[page][cityName] = num
			numList[page].push(num)
		})
		max[page] = Math.max(...numList[page])
		min[page] = Math.min(...numList[page])
		dif[page] = max[page] - min[page]
	}

	function initGreedyData(page) {
		numList[page] = []
		$.each(cities, function(index, city) {
			var cityName = city.properties.lga
			var num = propNum[page][cityName] || 0

			numList[page].push(num)
		})
		max[page] = Math.max(...numList[page])
		min[page] = Math.min(...numList[page])
		dif[page] = max[page] - min[page]
	}

	function initData() {
		$.getJSON('../data/finnalCrimeData.json', function(data, textStatus, jqXHR) {
			cities = data.features
			initIndexData('theft', 'crime')
			mapInit('theft', 'crime')
			initIndexData('median_aud', 'income')
			mapInit('median_aud', 'income')
			initIndexData('drug', 'drug')
			mapInit('drug', 'drug')
			initTwitterData()
		})
	}

	function addLayers(map, type, page) {
		var _type = type || 'theft'
		$.each(cities, function(index, city) {
			var cityName = city.properties.lga
			var scale = _type === 'greedy' ? 3 : 2
			var range = Math.floor(Math.pow((max[page] - propNum[page][cityName]) / dif[page], scale) * 10)

			console.log(cityName, '---', city.properties.b40_theft, '---', range)
			map.addLayer({
				id: 'maine' + page + index,
				type: 'fill',
				source: {
					type: 'geojson',
					data: '../data/cities/' + cityName + '.json'
				},
				paint: {
					'fill-color': colorList[range] || colorList[9],
					'fill-opacity': 0.8
				}
			})

			if (_type === 'greedy') {
				map.addLayer({
					id: 'points' + page + index,
					type: 'symbol',
					source: {
						type: 'geojson',
						data: cityPos[cityName]
					},
					layout: {
						'text-field': `{lga}: ${propNum.greedy[cityName] || 'unkonwn'}`,
						'text-offset': [0, 0.6]
					}
				})
			} else {
				map.addLayer({
					id: 'points' + page + index,
					type: 'symbol',
					source: {
						type: 'geojson',
						data: cityPos[cityName]
					},
					layout: {
						'text-field': `{lga}: {${_type}}`,
						'text-offset': [0, 0.6]
					}
				})
			}
		})
	}
	function mapInit(type, page, greedy) {
		mapboxgl.accessToken = 'pk.eyJ1IjoiY29hY28iLCJhIjoiY2pzbXF6Y3V1MDRocTN5cGdyemQyeW1sbiJ9.0jqcPjk3YbHBnjSlQxLOOQ'
		map[page] = new mapboxgl.Map({
			container: `${page}Map`,
			style: 'mapbox://styles/mapbox/streets-v8',
			center: [144.9631608, -37.8142176],
			zoom: 6
		})

		var nav = new mapboxgl.NavigationControl()
		map[page].addControl(nav, 'top-left')

		map[page].on('load', function() {
			addLayers(map[page], type, greedy || page)
		})
	}

	function gambligMapInit() {
		mapboxgl.accessToken = 'pk.eyJ1IjoiY29hY28iLCJhIjoiY2pzbXF6Y3V1MDRocTN5cGdyemQyeW1sbiJ9.0jqcPjk3YbHBnjSlQxLOOQ'
		var map = new mapboxgl.Map({
			container: 'gamblingMap',
			style: 'mapbox://styles/mapbox/streets-v8',
			center: [144.9631608, -37.8142176],
			zoom: 6
		})

		map.on('load', function() {
			// Add a new source from our GeoJSON data and set the
			// 'cluster' option to true. GL-JS will add the point_count property to your source data.
			map.addSource('earthquakes', {
				type: 'geojson',
				// Point to GeoJSON data. This example visualizes all M1.0+ earthquakes
				// from 12/22/15 to 1/21/16 as logged by USGS' Earthquake hazards program.
				data: './data/gambling.geojson',
				cluster: true,
				clusterMaxZoom: 14, // Max zoom to cluster points on
				clusterRadius: 50 // Radius of each cluster when clustering points (defaults to 50)
			})

			map.addLayer({
				id: 'clusters',
				type: 'circle',
				source: 'earthquakes',
				filter: ['has', 'point_count'],
				paint: {
					// Use step expressions (https://docs.mapbox.com/mapbox-gl-js/style-spec/#expressions-step)
					// with three steps to implement three types of circles:
					//   * Blue, 20px circles when point count is less than 100
					//   * Yellow, 30px circles when point count is between 100 and 750
					//   * Pink, 40px circles when point count is greater than or equal to 750
					'circle-color': ['step', ['get', 'point_count'], '#51bbd6', 20, '#f1f075', 50, '#f28cb1'],
					'circle-radius': ['step', ['get', 'point_count'], 20, 100, 30, 750, 40]
				}
			})

			map.addLayer({
				id: 'cluster-count',
				type: 'symbol',
				source: 'earthquakes',
				filter: ['has', 'point_count'],
				layout: {
					'text-field': '{point_count_abbreviated}',
					'text-font': ['DIN Offc Pro Medium', 'Arial Unicode MS Bold'],
					'text-size': 12
				}
			})

			map.addLayer({
				id: 'unclustered-point',
				type: 'circle',
				source: 'earthquakes',
				filter: ['!', ['has', 'point_count']],
				paint: {
					'circle-color': '#11b4da',
					'circle-radius': 4,
					'circle-stroke-width': 1,
					'circle-stroke-color': '#fff'
				}
			})

			// inspect a cluster on click
			map.on('click', 'clusters', function(e) {
				var features = map.queryRenderedFeatures(e.point, { layers: ['clusters'] })
				var clusterId = features[0].properties.cluster_id
				map.getSource('earthquakes').getClusterExpansionZoom(clusterId, function(err, zoom) {
					if (err) return

					map.easeTo({
						center: features[0].geometry.coordinates,
						zoom: zoom
					})
				})
			})

			map.on('mouseenter', 'clusters', function() {
				map.getCanvas().style.cursor = 'pointer'
			})
			map.on('mouseleave', 'clusters', function() {
				map.getCanvas().style.cursor = ''
			})
		})
	}

	function initTwitterData() {
		$.ajax({
			type: 'get',
			url: allUrl,
			dataType: 'json'
		}).then(function(res) {
			var allTwitter = res.rows
			$.each(allTwitter, function(index, item) {
				twitterInfo.all[item.key[0]] = item.value
			})
			$.ajax({
				type: 'get',
				url: locationUrl,
				dataType: 'json'
			}).then(function(res) {
				var localTwitter = res.rows
				$.each(localTwitter, function(index, item) {
					twitterInfo.local[item.key[0]] = item.value
					twitterInfo.percent[item.key[0]] = Number(
						((twitterInfo.local[item.key[0]] / twitterInfo.all[item.key[0]]) * 100).toFixed(2)
					)

					if (cityPos[item.key[0]]) {
						chartData.crime.push({
							city: item.key[0],
							x: twitterInfo.percent[item.key[0]],
							y: propNum.crime[item.key[0]]
						})
						chartData.income.push({
							city: item.key[0],
							x: twitterInfo.percent[item.key[0]],
							y: propNum.income[item.key[0]]
						})
						chartData.drug.push({
							city: item.key[0],
							x: twitterInfo.percent[item.key[0]],
							y: propNum.drug[item.key[0]]
						})
					}
				})
				propNum.greedy = twitterInfo.percent
				initGreedyData('greedy')
				renderChart('crime-chart', chartData.crime, { name: 'crime' })
				renderChart('income-chart', chartData.income, { name: 'income' })
				renderChart('drug-chart', chartData.drug, { name: 'drug' })
			})
		})
	}

	$('.mapBtns .aurine').on('click', function(e) {
		var type = $(this).text()
		var page = $(this).data('page')
		if ($(this).hasClass('checked')) {
			return
		} else {
			$(this)
				.siblings()
				.removeClass('checked')
			$(this).addClass('checked')
		}

		if (page === 'gambling') {
			gambligMapInit()
			return
		}
		map[page] && map[page].remove()
		initIndexData(type, page)
		mapInit(type, page)
	})

	$('.twitter-greedy').on('click', function(e) {
		$(this)
			.siblings('a')
			.removeClass('checked')
		var type = $(this).data('type')
		var page = $(this).data('page')
		map[page] && map[page].remove()
		mapInit(type, page, 'greedy')
	})

	initData()
	gambligMapInit()
	renderChart()
})
