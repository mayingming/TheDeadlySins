function renderChart(id, data, opt) {
	// var data = [{ lga: 'female', x: 161.2, y: 51.6 }]
	var chart = new G2.Chart({
		container: id,
		forceFit: true,
		height: $('#' + id).height(),
		padding: [20, 20, 40, 60]
	})
	chart.source(data)

	chart.tooltip({
		showTitle: false,
		crosshairs: {
			type: 'cross'
		},
		itemTpl:
			'<li data-index={index} style="margin-bottom:4px;">' +
			'<span style="background-color:{color};" class="g2-tooltip-marker"></span>' +
			'{name}<br/>' +
			'{value}' +
			'</li>'
	})
	chart
		.point()
		.position('x*y')
		.size(10)
		.shape('circle')
		.opacity(0.65)
		.color('city')
		.tooltip('city*x*y', function(city, x, y) {
			return {
				name: 'lga:' + city,
				value: opt.name + ': ' + x + '%, ' + 'greedy: ' + y + ' times'
			}
		})
	chart.render()
}
